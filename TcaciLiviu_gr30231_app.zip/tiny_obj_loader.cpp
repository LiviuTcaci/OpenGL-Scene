#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"

